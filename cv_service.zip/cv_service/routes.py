from fastapi import APIRouter, HTTPException, Depends, Header, File, UploadFile
from sqlalchemy.orm import Session
from schemas import CVCreate, CVCustomize, CVPreview, CVSave, CVDownload
from models import CV
from database import get_db
from utils import verify_user_exists
import os
import shutil

router=APIRouter()

@router.post("/cv/create")
def create_cv(cv_data:CVCreate, authorization:str = Header(...), db:Session=Depends(get_db)):
    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Invalid token format")
    token = authorization.split(" ")[1]
    user_info=verify_user_exists(token)

    if user_info.get("role") != "candidate":
        raise HTTPException(status_code=403, detail="Access restricted to candidates only")

    owner_id=user_info.get("id")
    if not owner_id:
        raise HTTPException(status_code=400, detail="Owner ID is missing from user information")
    
    new_cv = CV(**cv_data.dict(), owner_id=owner_id)
    db.add(new_cv)
    db.commit()
    db.refresh(new_cv)
    return new_cv

@router.put("/cv/customize")
def customize_cv(cv_id: int, customize_data: CVCustomize, authorization: str = Header(...), db: Session = Depends(get_db)):
    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Invalid token format")

    token = authorization.split(" ")[1]
    user_info = verify_user_exists(token)

    if user_info.get("role") != "candidate":
        raise HTTPException(status_code=403, detail="Access restricted to candidates only")

    owner_id = user_info.get("id")
    if not owner_id:
        raise HTTPException(status_code=400, detail="Owner ID is missing from user information")
    
    cv = db.query(CV).filter(CV.id == cv_id, CV.owner_id == owner_id).first()
    if not cv:
        raise HTTPException(status_code=404, detail="CV not found or access unauthorized")
    cv.layout = customize_data.layout
    db.commit()
    db.refresh(cv)
    return {"message": "CV layout updated successfully"}

@router.get("/cv/preview", response_model=CVPreview)
def preview_cv(cv_id: int, authorization: str = Header(...), db: Session = Depends(get_db)):
    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Invalid token format")

    token = authorization.split(" ")[1]
    user_info = verify_user_exists(token)

    if user_info.get("role") != "candidate":
        raise HTTPException(status_code=403, detail="Access restricted to candidates only")

    owner_id = user_info.get("id")
    if not owner_id:
        raise HTTPException(status_code=400, detail="Owner ID is missing from user information")

    cv = db.query(CV).filter(CV.id == cv_id, CV.owner_id == owner_id).first()
    if not cv:
        raise HTTPException(status_code=404, detail="CV not found or access unauthorized")
    return cv

@router.post("/cv/save")
def save_cv(cv_data: CVSave, authorization: str = Header(...), db: Session = Depends(get_db)):
    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Invalid token format")
    
    token = authorization.split(" ")[1]
    user_info = verify_user_exists(token)

    if user_info.get("role") != "candidate":
        raise HTTPException(status_code=403, detail="Access restricted to candidates only")

    owner_id = user_info.get("id")

    cv = db.query(CV).filter(CV.id == cv_data.id, CV.owner_id == owner_id).first()
    if not cv:
        raise HTTPException(status_code=404, detail="CV not found or access unauthorized")

    cv.saved = True
    db.commit()
    return {"message": "CV saved as official"}

@router.post("/cv/download")
def download_cv(cv_data: CVDownload, authorization: str = Header(...), db: Session = Depends(get_db)):
    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Invalid token format")
    
    token = authorization.split(" ")[1]
    user_info = verify_user_exists(token)

    if user_info.get("role") != "candidate":
        raise HTTPException(status_code=403, detail="Access restricted to candidates only")

    owner_id = user_info.get("id")

    cv = db.query(CV).filter(CV.id == cv_data.id, CV.owner_id == owner_id).first()
    if not cv:
        raise HTTPException(status_code=404, detail="CV not found or access unauthorized")
    return {"message": "CV ready for download as PDF"}

@router.get("/cv/{id}")
def get_cv(id: int, authorization: str = Header(...), db: Session = Depends(get_db)):
    print(f"Fetching CV with ID: {id}")

    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Invalid token format")
    token = authorization.split(" ")[1]

    user_info = verify_user_exists(token)
    print(f"User info from token: {user_info}")

    if user_info.get("role") != "candidate":
        raise HTTPException(status_code=403, detail="Access restricted to candidates only")

    owner_id = user_info.get("id")
    print(f"Owner ID: {owner_id}")

    cv = db.query(CV).filter(CV.id == id, CV.owner_id == owner_id).first()
    if not cv:
        print(f"CV not found or unauthorized access for ID: {id}")
        raise HTTPException(status_code=404, detail="CV not found or access unauthorized")

    print(f"CV found: {cv}")

    # Génération dynamique du champ `text`
    cv_text = f"{cv.skills} {cv.experience} {cv.education} {cv.languages} {cv.projects or ''}".strip()

    return {
        "id": cv.id,
        "owner_id": cv.owner_id,
        "skills": cv.skills,
        "experience": cv.experience,
        "education": cv.education,
        "certifications": cv.certifications,
        "languages": cv.languages,
        "projects": cv.projects,
        "text": cv_text,  # Ajout du champ calculé
    }


upload_dir = "./uploaded_cvs"
if not os.path.exists(upload_dir):
    os.makedirs(upload_dir)

allowed_formats = {".pdf",".doc",".docx"}

@router.post("/cv/upload")
async def upload_cv(
    file: UploadFile = File(...),
    authorization: str = Header(...),
    db: Session = Depends(get_db)
):
    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Invalid token format")
   
    token = authorization.split(" ")[1]

    user_info = verify_user_exists(token)

    if user_info.get("role") != "candidate":
        raise HTTPException(status_code=403, detail="Access restricted to candidates only")

    owner_id=user_info.get("id")

    file_extension=os.path.splitext(file.filename)[1].lower()
    if file_extension not in allowed_formats:
        raise HTTPException(status_code=400,detail="File type not allowed. Please upload a content of type PDF, DOC or DOCX")

    file_location = os.path.join(upload_dir, f"{owner_id}_{file.filename}")

    with open(file_location, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    new_cv= CV(
        owner_id=owner_id,
        skills="",
        experience="",
        education="",
        certifications="",
        languages="",
        projects="",
        layout="",
    )
    new_cv.file_path = file_location

    db.add(new_cv)
    db.commit()
    db.refresh(new_cv)

    return {"message": "CV successfully uploaded", "cv_id": new_cv.id, "file_path":file_location}

@router.delete("/cv/{id}")
def delete_cv(id: int, authorization: str = Header(...), db: Session = Depends(get_db)):
    
    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Invalid token format")

    token = authorization.split(" ")[1]
    user_info = verify_user_exists(token)

    if user_info.get("role") != "candidate":
        raise HTTPException(status_code=403, detail="Access restricted to candidates only")

    owner_id = user_info.get("id")
    
    cv = db.query(CV).filter(CV.id == id, CV.owner_id == owner_id).first()
    if not cv:
        raise HTTPException(status_code=404, detail="CV not found or access unauthorized")

    if cv.file_path and os.path.exists(cv.file_path):
        os.remove(cv.file_path)

    db.delete(cv)
    db.commit()

    return {"message": "CV successfully deleted", "cv_id": id}