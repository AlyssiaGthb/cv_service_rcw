from sqlalchemy import Column, Integer, String, Text
from database import Base
from datetime import datetime
from sqlalchemy.ext.hybrid import hybrid_property


class CV(Base):
    __tablename__='cvs'

    id = Column(Integer,primary_key=True,index=True,autoincrement=True)
    owner_id=Column(Integer,nullable=False)
    skills=Column(Text)
    experience=Column(Text)
    education=Column(Text)
    certifications=Column(Text,nullable=True)
    languages=Column(Text,nullable=False)
    projects=Column(Text,nullable=True)
    layout=Column(String,nullable=True)
    created_at=Column(String,default=datetime.utcnow)
    updated_at=Column(String,default=datetime.utcnow,onupdate=datetime.utcnow)
    file_path= Column(String, nullable=True)
    @hybrid_property
    def text(self):
        # Générer dynamiquement le champ text
        return f"{self.skills} {self.experience} {self.education} {self.languages} {self.projects or ''}"
    