from fastapi import HTTPException
import requests
from dotenv import load_dotenv
import os

load_dotenv()

AUTH_URL = os.getenv("AUTH_URL")

def verify_user_exists(token:str):
    try:
        headers={"Authorization":f"Bearer {token}"}
        response = requests.get(f"{AUTH_URL}/user-profile", headers=headers)
        if response.status_code != 200:
            raise HTTPException(status_code=404,detail="User not found or token invalid")
        return response.json()
    except requests.exceptions.RequestException:
        raise HTTPException(status_code=500,detail="Could not verify with auth_service")
